package Banco;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Principal {

	public static void main(String[] args) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("Banco");
		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();
		
		Conta c1 = new Conta(new ContaID("11111111111", "22222222222"), "Carlos", "camelo_22@outlook.com", "22", 49, 100.10);
		
		ContaID ci = new ContaID();
		ci.setCpf("12345678912");
		ci.setRg("12345678900");
		Conta c2 = new Conta();
		c2.setId(ci);
		c2.setNome("Gabriel");
		c2.setIdade(22);
		c2.setEmail("lerrizinDuGrau@hotmail.com");
		c2.setNroConta("1021");
		c2.setSaldo(100.00);
		
		em.persist(c1);
		em.persist(c2);
		
		em.getTransaction().commit();
		em.close();
		emf.close();
	}
}
