package Banco;

import java.io.Serializable;




public class ContaID implements Serializable{
	private static final long serialVersionUID = 1L;
	String rg;
	String cpf;
	
	public ContaID() {
		
	}
	
	public ContaID(String rg, String cpf) {
		this.rg = rg;
		this.cpf = cpf;
	}
	
	@Override
	public String toString() {
		return "ContaID [rg=" + rg + ", cpf=" + cpf + "]";
	}
	
	public String getRg() {
		return rg;
	}
	public void setRg(String rg) {
		this.rg = rg;
	}
	public String getCpf() {
		return cpf;
	}
	public void setCpf(String cpf) {
		this.cpf = cpf;
	}
	
}
